<?php foreach ($all_videos as $videos): ?>
<div class="col-md-3 col-sm-4 col-xs-6">
    <?php include('thumbnail.php'); ?>
</div>
<?php endforeach; ?>
